import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User, signOut } from 'firebase/auth';
import { auth, testConnection } from './lib/firebase';
import { ViewState, CheckRecord } from './types';
import Auth from './components/Auth';
import History from './components/History';
import CheckForm from './components/CheckForm';
import RecordDetails from './components/RecordDetails';
import { Shield, PlusCircle, History as HistoryIcon, LogOut, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<ViewState>('history');
  const [selectedRecord, setSelectedRecord] = useState<CheckRecord | null>(null);
  const [editingRecord, setEditingRecord] = useState<CheckRecord | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    testConnection();
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center">
        <Shield className="w-16 h-16 text-blue-600 animate-pulse mb-4" />
        <p className="text-blue-500 font-mono text-xs uppercase tracking-[0.3em] font-bold">FORÇA TÁTICA CERRADO</p>
        <p className="text-slate-600 font-mono text-[8px] uppercase tracking-[0.2em] mt-2">Iniciando Protocolo Seguros...</p>
      </div>
    );
  }

  if (!user) {
    return <Auth />;
  }

  const navigateToDetails = (record: CheckRecord) => {
    setSelectedRecord(record);
    setView('details');
  };

  const handleEdit = (record: CheckRecord) => {
    setEditingRecord(record);
    setView('new-check');
  };

  const handleNewCheck = () => {
    setEditingRecord(undefined);
    setView('new-check');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-blue-500/30">
      {/* Dynamic Content */}
      <main className="pb-20">
        <AnimatePresence mode="wait">
          {view === 'history' && (
            <motion.div key="history" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <History onSelectRecord={navigateToDetails} />
            </motion.div>
          )}
          {view === 'new-check' && (
            <motion.div key="form" initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
              <CheckForm 
                onSuccess={() => setView('history')} 
                onCancel={() => setView('history')} 
                initialData={editingRecord}
              />
            </motion.div>
          )}
          {view === 'details' && selectedRecord && (
            <motion.div key="details" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }}>
              <RecordDetails 
                record={selectedRecord} 
                onBack={() => setView('history')} 
                onEdit={handleEdit}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Navigation Bar */}
      <nav className="fixed bottom-0 left-0 w-full bg-slate-900/80 backdrop-blur-xl border-t border-slate-800 px-6 py-3 z-50">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <button 
            onClick={() => setView('history')}
            className={`flex flex-col items-center gap-1 transition-all ${view === 'history' ? 'text-blue-500' : 'text-slate-500'}`}
          >
            <HistoryIcon className={`w-6 h-6 ${view === 'history' ? 'scale-110' : ''}`} />
            <span className="text-[10px] uppercase font-bold tracking-widest">Histórico</span>
          </button>

          <button 
            onClick={handleNewCheck}
            className={`-translate-y-6 w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all active:scale-90 ${view === 'new-check' ? 'bg-blue-500 text-white rotate-45' : 'bg-blue-600 text-white'}`}
          >
            <PlusCircle className="w-8 h-8" />
          </button>

          <button 
            onClick={() => {
              if (window.confirm("Deseja sair do sistema?")) signOut(auth);
            }}
            className="flex flex-col items-center gap-1 text-slate-500 hover:text-red-400 transition-colors"
          >
            <LogOut className="w-6 h-6" />
            <span className="text-[10px] uppercase font-bold tracking-widest">Sair</span>
          </button>
        </div>
      </nav>

      {/* Overlay decorations */}
      <div className="fixed top-0 left-0 w-full pointer-events-none opacity-20 bg-gradient-to-b from-blue-600/10 to-transparent h-64 z-0" />
    </div>
  );
}
