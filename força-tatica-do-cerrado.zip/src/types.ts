export interface CheckRecord {
  id?: string;
  fullName: string;
  cpf: string;
  rg: string;
  birthDate: string;
  motherName: string;
  fatherName: string;
  address: string;
  naturality: string;
  criminalRecords: string;
  photo?: string; // base64
  createdAt: any; // Timestamp
  createdBy: string;
}

export type ViewState = 'history' | 'new-check' | 'details' | 'auth';
