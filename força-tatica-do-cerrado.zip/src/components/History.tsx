import React, { useState, useEffect } from 'react';
import { Search, User, Calendar, FileText, ChevronRight, Filter, Eye, Clock, Shield } from 'lucide-react';
import { collection, query, orderBy, onSnapshot, where } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { CheckRecord } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface HistoryProps {
  onSelectRecord: (record: CheckRecord) => void;
}

export default function History({ onSelectRecord }: HistoryProps) {
  const [records, setRecords] = useState<CheckRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, 'checks'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as CheckRecord[];
      setRecords(docs);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'checks');
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const filteredRecords = records.filter(r => 
    r.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.cpf?.includes(searchTerm)
  );

  return (
    <div className="bg-slate-950 min-h-screen text-slate-100 pb-24">
      <div className="max-w-4xl mx-auto p-4">
        {/* Header */}
        <div className="flex flex-col gap-6 mb-8 mt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-slate-900 rounded-lg overflow-hidden border border-slate-800 shrink-0">
                <img 
                  src="https://ais-pre-yxasw665yvi7m7jzthwges-371774702210.us-east1.run.app/attachments/7e9c56ca-6f0a-413d-88b0-68194dc6221d" 
                  className="w-full h-full object-cover" 
                  alt="Emblema" 
                />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="text-[10px] font-bold text-amber-500 uppercase tracking-widest font-mono">Força Tática Cerrado</span>
                </div>
                <h2 className="text-2xl font-bold tracking-tight">Abordagens</h2>
              </div>
            </div>
            <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center border border-slate-800 shadow-lg">
              <Clock className="w-6 h-6 text-slate-400" />
            </div>
          </div>

          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
            <input 
              type="text"
              placeholder="Buscar por Nome ou CPF..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-2xl pl-12 pr-4 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all text-sm"
            />
          </div>
        </div>

        {/* List */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 grayscale opacity-50">
            <div className="w-12 h-12 border-2 border-slate-800 border-t-blue-500 rounded-full animate-spin mb-4" />
            <p className="text-slate-500 font-mono text-xs uppercase tracking-widest">Sincronizando Banco de Dados...</p>
          </div>
        ) : filteredRecords.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 bg-slate-900/50 border border-slate-800 border-dashed rounded-3xl">
            <Shield className="w-12 h-12 text-slate-800 mb-4" />
            <p className="text-slate-500 text-center px-8">Nenhum registro encontrado para {searchTerm ? `"${searchTerm}"` : 'esta conta'}.</p>
          </div>
        ) : (
          <div className="grid gap-3">
            <AnimatePresence>
              {filteredRecords.map((record, index) => (
                <motion.div
                  key={record.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => onSelectRecord(record)}
                  className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-4 rounded-2xl cursor-pointer group active:scale-[0.99] transition-all flex items-center gap-4"
                >
                  <div className="w-16 h-16 bg-slate-950 rounded-xl overflow-hidden border border-slate-800 shrink-0">
                    {record.photo ? (
                      <img src={record.photo} alt={record.fullName} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-slate-800">
                        <User className="w-6 h-6 text-slate-600" />
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-white truncate">{record.fullName}</h3>
                    <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                      <span className="font-mono">{record.cpf}</span>
                      <span className="w-1 h-1 bg-slate-700 rounded-full" />
                      <span>{record.createdAt?.toDate ? new Date(record.createdAt.toDate()).toLocaleDateString('pt-BR') : 'Recent'}</span>
                    </div>
                  </div>

                  <div className="p-2 bg-slate-800/50 rounded-lg group-hover:bg-blue-600/20 group-hover:text-blue-400 text-slate-500 transition-colors">
                    <ChevronRight className="w-5 h-5" />
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
