import React from 'react';
import { ChevronLeft, User, FileText, Calendar, MapPin, Shield, Info, Download, Share2 } from 'lucide-react';
import { CheckRecord } from '../types';
import { motion } from 'motion/react';

interface RecordDetailsProps {
  record: CheckRecord;
  onBack: () => void;
  onEdit: (record: CheckRecord) => void;
}

export default function RecordDetails({ record, onBack, onEdit }: RecordDetailsProps) {
  const handleShare = () => {
    const message = `
🚨 *RELATÓRIO DE ABORDAGEM* 🚨
*FORÇA TÁTICA CERRADO*

👤 *DADOS DO ABORDADO:*
*NOME:* ${record.fullName}
*CPF:* ${record.cpf}
*RG:* ${record.rg || 'Não informado'}
*DATA NASC.:* ${record.birthDate}
*MÃE:* ${record.motherName || 'Não informada'}
*PAI:* ${record.fatherName || 'Não informado'}
*NATURALIDADE:* ${record.naturality || 'Não informada'}

📍 *ENDEREÇO:*
${record.address || 'Não informado'}

⚠️ *PASSAGENS / OBS:*
${record.criminalRecords || 'Nada consta ou não informado'}

━━━━━━━━━━━━━━━━
📅 *REGISTRO:* ${record.createdAt?.toDate ? new Date(record.createdAt.toDate()).toLocaleString('pt-BR') : '---'}
👮 *AGENTE:* ID-${record.createdBy.slice(0, 8)}
    `.trim();

    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/?text=${encodedMessage}`, '_blank');
  };

  const metaItems = [
    { label: 'CPF', value: record.cpf, icon: FileText },
    { label: 'RG', value: record.rg || 'Não informado', icon: FileText },
    { label: 'Nascimento', value: record.birthDate, icon: Calendar },
    { label: 'Naturalidade', value: record.naturality, icon: MapPin },
    { label: 'Mãe', value: record.motherName, icon: User },
    { label: 'Pai', value: record.fatherName, icon: User },
  ];

  return (
    <div className="bg-slate-950 min-h-screen text-slate-100 pb-12">
      <div className="max-w-2xl mx-auto p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button onClick={onBack} className="p-2 hover:bg-slate-900 rounded-full transition-colors">
              <ChevronLeft className="w-6 h-6" />
            </button>
            <h2 className="text-xl font-bold tracking-tight">Ficha de Abordagem</h2>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => onEdit(record)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600/10 hover:bg-blue-600/20 text-blue-500 rounded-xl transition-all border border-blue-500/20 font-bold text-xs"
            >
              Editar
            </button>
            <button 
              onClick={handleShare}
              className="flex items-center gap-2 px-4 py-2 bg-green-600/10 hover:bg-green-600/20 text-green-500 rounded-xl transition-all border border-green-500/20 font-bold text-xs"
            >
              <Share2 className="w-4 h-4" />
              WhatsApp
            </button>
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Profile Header */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col items-center">
            <div className="w-40 h-40 bg-slate-950 rounded-2xl overflow-hidden border-2 border-blue-500/20 mb-6 shadow-2xl">
              {record.photo ? (
                <img src={record.photo} alt={record.fullName} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-slate-800">
                  <User className="w-16 h-16 text-slate-600" />
                </div>
              )}
            </div>
            <h1 className="text-2xl font-bold text-center mb-1">{record.fullName}</h1>
            <div className="px-3 py-1 bg-slate-800 border border-slate-700 rounded-full text-[10px] uppercase tracking-widest text-slate-400 font-bold">
              ID: {record.id?.slice(-8).toUpperCase()}
            </div>
          </div>

          {/* Grid Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {metaItems.map((item, idx) => (
              <div key={idx} className="bg-slate-900/50 border border-slate-800 rounded-2xl p-4 flex gap-4 items-start">
                <div className="p-2 bg-slate-800 rounded-lg text-slate-500">
                  <item.icon className="w-4 h-4" />
                </div>
                <div>
                  <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">{item.label}</label>
                  <p className="text-sm font-medium mt-1">{item.value || '---'}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Full Width Info */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-4 flex gap-4 items-start">
            <div className="p-2 bg-slate-800 rounded-lg text-slate-500">
              <MapPin className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Endereço Residencial</label>
              <p className="text-sm font-medium mt-1">{record.address || 'Não informado'}</p>
            </div>
          </div>

          {/* Criminal Records */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4 text-amber-500">
              <Shield className="w-5 h-5" />
              <h3 className="font-bold text-sm uppercase tracking-[0.15em]">Passagens Criminais / Prontuário</h3>
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 min-h-[100px]">
              {record.criminalRecords ? (
                <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap">{record.criminalRecords}</p>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-600 italic py-4">
                  <Info className="w-5 h-5 mb-2 opacity-20" />
                  <p className="text-xs italic">Nenhum registro criminal informado no ato da abordagem.</p>
                </div>
              )}
            </div>
          </div>

          {/* Footer Metadata */}
          <div className="flex flex-col gap-2 pt-6 border-t border-slate-900">
            <div className="flex justify-between text-[10px] text-slate-600 uppercase tracking-widest font-mono">
              <span>Registrado em:</span>
              <span>{record.createdAt?.toDate ? new Date(record.createdAt.toDate()).toLocaleString('pt-BR') : '---'}</span>
            </div>
            <div className="flex justify-between text-[10px] text-slate-600 uppercase tracking-widest font-mono">
              <span>Agente:</span>
              <span>UID {record.createdBy.slice(0, 8)}</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
