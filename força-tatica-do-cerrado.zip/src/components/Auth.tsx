import React from 'react';
import { auth, googleProvider } from '../lib/firebase';
import { signInWithPopup } from 'firebase/auth';
import { Shield, Lock } from 'lucide-react';
import { motion } from 'motion/react';

export default function Auth() {
  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6 font-sans">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-600 to-indigo-600" />
        
        <div className="flex flex-col items-center text-center mb-8">
          <div className="relative mb-6">
            <div className="w-32 h-32 bg-slate-900 rounded-2xl flex items-center justify-center border border-slate-800 shadow-[0_0_50px_rgba(0,0,0,0.5)] overflow-hidden">
              <img 
                src="https://ais-pre-yxasw665yvi7m7jzthwges-371774702210.us-east1.run.app/attachments/7e9c56ca-6f0a-413d-88b0-68194dc6221d" 
                className="w-full h-full object-cover" 
                alt="Logo Força Tática Cerrado" 
              />
            </div>
          </div>
          <h1 className="text-3xl font-black text-white tracking-tighter mb-1 uppercase">FORÇA TÁTICA</h1>
          <p className="text-amber-500 font-mono text-sm font-bold tracking-[0.2em] mb-4">CERRADO • RT26</p>
          <div className="h-px w-12 bg-slate-800 mx-auto mb-4" />
          <p className="text-slate-400 text-sm max-w-[200px]">Sistema Blindado de Registro de Abordagens</p>
        </div>

        <div className="space-y-4">
          <button
            onClick={handleLogin}
            className="w-full flex items-center justify-center gap-3 bg-white hover:bg-slate-100 text-slate-900 py-4 px-6 rounded-xl font-semibold transition-all shadow-lg active:scale-95"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-6 h-6" alt="Google" />
            Entrar com Google
          </button>
          
          <div className="flex items-center gap-2 justify-center text-slate-500 text-xs mt-6">
            <Lock className="w-3 h-3" />
            <span>Conexão criptografada e segura</span>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-slate-800 text-center">
          <p className="text-slate-500 text-[10px] uppercase tracking-widest leading-relaxed">
            O uso indevido deste sistema está sujeito a sanções administrativas e penais.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
