import React, { useState, useRef, useEffect } from 'react';
import { Camera, Upload, User, MapPin, Calendar, FileText, ChevronLeft, Save, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { addDoc, collection, serverTimestamp, updateDoc, doc } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { CheckRecord } from '../types';

interface CheckFormProps {
  onSuccess: () => void;
  onCancel: () => void;
  initialData?: CheckRecord;
}

export default function CheckForm({ onSuccess, onCancel, initialData }: CheckFormProps) {
  const [formData, setFormData] = useState<Partial<CheckRecord>>(initialData ? {
    fullName: initialData.fullName,
    cpf: initialData.cpf,
    rg: initialData.rg,
    birthDate: initialData.birthDate,
    motherName: initialData.motherName,
    fatherName: initialData.fatherName,
    address: initialData.address,
    naturality: initialData.naturality,
    criminalRecords: initialData.criminalRecords,
  } : {
    fullName: '',
    cpf: '',
    rg: '',
    birthDate: '',
    motherName: '',
    fatherName: '',
    address: '',
    naturality: '',
    criminalRecords: '',
  });
  
  const [photo, setPhoto] = useState<string | null>(initialData?.photo || null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
      }
    } catch (err) {
      console.error("Error accessing camera", err);
      alert("Não foi possível acessar a câmera.");
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      setIsCameraActive(false);
    }
  };

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(video, 0, 0);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
      setPhoto(dataUrl);
      stopCamera();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    
    setLoading(true);
    try {
      const path = 'checks';
      if (initialData?.id) {
        // Edit mode
        await updateDoc(doc(db, path, initialData.id), {
          ...formData,
          photo,
          updatedAt: serverTimestamp(),
        });
      } else {
        // Create mode
        await addDoc(collection(db, path), {
          ...formData,
          photo,
          createdBy: auth.currentUser.uid,
          createdAt: serverTimestamp(),
        });
      }
      onSuccess();
    } catch (error) {
      handleFirestoreError(error, initialData?.id ? OperationType.UPDATE : OperationType.CREATE, 'checks');
    } finally {
      setLoading(false);
    }
  };

  const updateField = (field: keyof CheckRecord, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="bg-slate-950 min-h-screen text-slate-100 pb-12">
      <div className="max-w-2xl mx-auto p-4">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button onClick={onCancel} className="p-2 hover:bg-slate-900 rounded-full transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-xl font-bold tracking-tight">Novo Registro de Abordagem</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Photo Section */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
            <label className="block text-xs font-semibold uppercase tracking-widest text-slate-500 mb-4">Capturar Imagem</label>
            <div className="flex flex-col items-center">
              {photo ? (
                <div className="relative w-full aspect-square max-w-sm rounded-xl overflow-hidden border-2 border-blue-500/30">
                  <img src={photo} alt="Thumbnail" className="w-full h-full object-cover" />
                  <button 
                    type="button"
                    onClick={() => setPhoto(null)}
                    className="absolute top-2 right-2 p-2 bg-red-600 rounded-full text-white shadow-lg"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : isCameraActive ? (
                <div className="relative w-full aspect-square max-w-sm bg-black rounded-xl overflow-hidden">
                  <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                  <div className="absolute bottom-4 left-0 w-full flex justify-center gap-4">
                    <button 
                      type="button"
                      onClick={takePhoto}
                      className="bg-white text-slate-900 p-4 rounded-full shadow-xl active:scale-90 transition-transform"
                    >
                      <Camera className="w-8 h-8" />
                    </button>
                    <button 
                      type="button"
                      onClick={stopCamera}
                      className="bg-slate-800/80 text-white p-4 rounded-full active:scale-90"
                    >
                      <X className="w-8 h-8" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex gap-4">
                  <button 
                    type="button"
                    onClick={startCamera}
                    className="flex flex-col items-center justify-center w-32 h-32 bg-slate-800 border-2 border-dashed border-slate-700 rounded-2xl hover:border-blue-500/50 hover:bg-slate-800/80 transition-all text-slate-400 hover:text-blue-400 group"
                  >
                    <Camera className="w-8 h-8 mb-2 group-hover:scale-110 transition-transform" />
                    <span className="text-xs font-medium">Câmera</span>
                  </button>
                  <label className="flex flex-col items-center justify-center w-32 h-32 bg-slate-800 border-2 border-dashed border-slate-700 rounded-2xl cursor-pointer hover:border-blue-500/50 hover:bg-slate-800/80 transition-all text-slate-400 hover:text-blue-400 group">
                    <Upload className="w-8 h-8 mb-2 group-hover:scale-110 transition-transform" />
                    <span className="text-xs font-medium">Upload</span>
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => setPhoto(reader.result as string);
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                </div>
              )}
            </div>
            <canvas ref={canvasRef} className="hidden" />
          </div>

          {/* Form Fields */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-slate-500">
                  <User className="w-3 h-3" /> Nome Completo
                </label>
                <input 
                  required
                  value={formData.fullName}
                  onChange={(e) => updateField('fullName', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                  placeholder="Nome do abordado"
                />
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-slate-500">
                  <FileText className="w-3 h-3" /> CPF
                </label>
                <input 
                  required
                  value={formData.cpf}
                  onChange={(e) => updateField('cpf', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-mono"
                  placeholder="000.000.000-00"
                />
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-slate-500">
                  <FileText className="w-3 h-3" /> RG
                </label>
                <input 
                  value={formData.rg}
                  onChange={(e) => updateField('rg', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-mono"
                  placeholder="00.000.000-0"
                />
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-slate-500">
                  <Calendar className="w-3 h-3" /> Data de Nascimento
                </label>
                <input 
                  type="date"
                  value={formData.birthDate}
                  onChange={(e) => updateField('birthDate', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                />
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-slate-800">
              <div className="space-y-2">
                <label className="text-xs font-semibold uppercase tracking-widest text-slate-500">Filiação (Mãe / Pai)</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input 
                    value={formData.motherName}
                    onChange={(e) => updateField('motherName', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                    placeholder="Nome da Mãe"
                  />
                  <input 
                    value={formData.fatherName}
                    onChange={(e) => updateField('fatherName', e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                    placeholder="Nome do Pai"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-slate-500">
                  <MapPin className="w-3 h-3" /> Endereço Residencial
                </label>
                <input 
                  value={formData.address}
                  onChange={(e) => updateField('address', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                  placeholder="Rua, Número, Bairro, Cidade"
                />
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-slate-500">
                  <MapPin className="w-3 h-3" /> Naturalidade
                </label>
                <input 
                  value={formData.naturality}
                  onChange={(e) => updateField('naturality', e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                  placeholder="Cidade/UF"
                />
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-slate-500">
                  <FileText className="w-3 h-3" /> Passagens Criminais / Observações
                </label>
                <textarea 
                  value={formData.criminalRecords}
                  onChange={(e) => updateField('criminalRecords', e.target.value)}
                  rows={4}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all resize-none"
                  placeholder="Descreva antecedentes ou observações da abordagem..."
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white py-4 rounded-2xl font-bold transition-all shadow-xl shadow-blue-900/20 flex items-center justify-center gap-2 disabled:cursor-not-allowed group active:scale-[0.98]"
          >
            {loading ? (
              <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Save className="w-5 h-5 group-hover:scale-110 transition-transform" />
                Finalizar Cadastro
              </>
            )}
          </button>
          
          <p className="text-center text-slate-600 text-[10px] uppercase tracking-[0.2em]">
            Protocolo de Segurança Ativo
          </p>
        </form>
      </div>
    </div>
  );
}
